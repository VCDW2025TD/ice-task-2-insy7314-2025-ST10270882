import { Link } from "react-router-dom";

const isLoggedIn = () => !!localStorage.getItem("token");

export default function Navbar() {
  return (
    <nav style={{ marginBottom: "20px" }}>
      <Link to="/dashboard" style={{ marginRight: "10px" }}>Home</Link>

      {isLoggedIn() ? (
        <>
          <Link to="/dashboard" style={{ marginRight: "10px" }}>Dashboard</Link>
          <Link to="/logout">Logout</Link>
        </>
      ) : (
        <>
          <Link to="/" style={{ marginRight: "10px" }}>Register</Link>
          <Link to="/login">Login</Link>
        </>
      )}
    </nav>
  );
}
