export function getUserRole(){
    return localStorage.getItem("role");
}