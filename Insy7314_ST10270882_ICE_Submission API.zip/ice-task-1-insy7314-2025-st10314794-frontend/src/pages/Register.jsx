import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import API from "../services/Api"; //axios setup
import { isValidEmail, isStrongPassword } from "../utils/validators";

export default function Register(){
    //State = variable sreact remembers
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [message, setMessage] = useState(""); //feedback message
    const [error, setError] = useState(""); //add this along with message state

    //added --> creating navigation function
    const navigate = useNavigate();

    //function that runs when user clicks "Register"
    const handleRegister = async(e) => {
        e.preventDefault(); //stop page from refreshing

        // //added validators 
        setError("");

        if (!email || !password) {
            setError("Email and password are required.");
            return;
        }
        if (!isValidEmail(email)){
            setError("Invalid email format.");
            return;
        }
        if (!isStrongPassword(password)){
            setError("Passord must be at least 8 characters and include letters and numbers.");
            return;
        }

        //
        try{
            //send data to backend
            // originally:

            //replaced with
            const res = await API.post("/auth/register", {email,password});

            //svae token into browser memory
            localStorage.setItem("token", res.data.token);

            //show scess message
            setMessage("Registration Successful");

            navigate("/dashboard");
        } catch(err){
            //show error if smth goes wrong
            setMessage("Error: " + (err.response?.data?.message | "Try again."));
        }
    };

    return(
        <div>
            <h2>Register</h2>

            <form onSubmit={handleRegister}>

                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)} //update email state
                    required
                />

                <br/>

                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e)=> setPassword(e.target.value)} //update passwordstate
                    required
                />
                <br/>
                <button type="Submit">Register</button>
                
            </form>

            {/* Success/Error messgae */}
            <p>{message}</p> 

            {/* Login Button */}
            <button onClick={() => navigate("/login")}>Login</button>
        </div>
    );
}