//rjigkrjgor
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import API from "../services/Api";
import { isValidEmail, isStrongPassword } from "../utils/validators";
import { getUserRole } from "../services/auth";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate(); // lets us redirect after login
  //added
   const [error, setError] = useState(""); 

  const handleLogin = async (e) => {
    e.preventDefault();
    // //validtors added (part 5)
     setError("");

    if (!email || !password) {
      setError("Email and password are required.");
      return;
    }
    if (!isValidEmail(email)) {
      setError("Invalid email format.");
      return;
    }
    if (!isStrongPassword(password)) {
      setError("Password must be at least 8 characters and include letters and numbers.");
      return;
    }

    ////
    try {
      // const res = await axios.post("http://localhost:5000/auth/login", {
    //   const res = await API.post("/auth/login", {
    //     email,
    //     password,
    //   });
      const res = await API.post("/auth/login", { email, password }, { withCredentials: true });


      // save token in localStorage
      localStorage.setItem("token", res.data.token);
      //added for rbac impl (custom)
      localStorage.setItem("role", res.data.user.role)

      // redirect to dashboard
      navigate("/dashboard");
    } catch (err) {
    console.error(err); // <- this shows full Axios error object
      setMessage("Login failed: " + (err.response?.data?.message || "Try again"));
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <br />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <br />
        <button type="submit">Login</button>
      </form>
      <p>{message}</p>

      {/* added */}
       {/* Button to go to login page */}
      <button onClick={() => navigate("/register")}>Register</button>
    </div>
  );
}
