import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function LogoutPage() {
  const navigate = useNavigate();

  useEffect(() => {
    //  remove token
    localStorage.removeItem("token");

    //  redirect to register ("/")
    navigate("/");
  }, [navigate]);

  return <p>Logging out...</p>;
}
