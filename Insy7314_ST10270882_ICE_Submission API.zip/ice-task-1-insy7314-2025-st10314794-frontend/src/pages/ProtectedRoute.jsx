import { Navigate} from "react-router-dom";

export default function ProtectedRoute({ children}){
    const token = localStorage.getItem("token") //checks if user has token

    if (!token){
        //if nmo token redirect to login
        return <Navigate to="/login"/>
    }

    //if tkken exists show the page
    return children;
}