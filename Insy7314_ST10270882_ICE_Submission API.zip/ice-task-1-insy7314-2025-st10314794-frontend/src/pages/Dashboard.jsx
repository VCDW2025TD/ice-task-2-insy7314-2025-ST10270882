import { getUserRole } from "../services/auth";

export default function Dashboard(){
    const role = getUserRole();
    const token = localStorage.getItem("token");

    if (!token){
        return <p>You must login first!</p> //Simple protection
    }

    return(
        <div>
           {role === "admin" && (
            <div>
                <h2>Welcome Admin</h2>
            </div>
           )}
            <h2>Welcome to the Dashboard</h2>
            <p>You have succesfully logged in as {role}!</p>
        </div>
    );
}