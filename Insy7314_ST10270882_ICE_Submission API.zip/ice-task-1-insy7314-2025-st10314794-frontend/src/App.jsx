import { useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

// function App() {
//   const [count, setCount] = useState(0)

//   return (
//     <>
//       <div>
//         <a href="https://vite.dev" target="_blank">
//           <img src={viteLogo} className="logo" alt="Vite logo" />
//         </a>
//         <a href="https://react.dev" target="_blank">
//           <img src={reactLogo} className="logo react" alt="React logo" />
//         </a>
//       </div>
//       <h1>Vite + React</h1>
//       <div className="card">
//         <button onClick={() => setCount((count) => count + 1)}>
//           count is {count}
//         </button>
//         <p>
//           Edit <code>src/App.jsx</code> and save to test HMR
//         </p>
//       </div>
//       <p className="read-the-docs">
//         Click on the Vite and React logos to learn more
//       </p>
//     </>
//   )
// }

//added imports
import axios from 'axios';
import API from './services/Api';
import Register from './pages/Register';
import Login from "./pages/Login";
import ProtectedRoute from './pages/ProtectedRoute';
import Dashboard from './pages/Dashboard';
import Navbar from "./components/Navbar"; 
import Logout from "./pages/Logout";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

function  App(){
  const [testMsg, setTestMsg] = useState('');

  // useEffect(() =>{
  //   API.get('/test')
  //   .then(res => setTestMsg(res.data.message))
  //   .catch(err => console.error(err));
  // }, []);

  return(
    <>
    {/* <h2>Welcome to Secure Blog (Version 3)</h2>
    <p>Backend says: {testMsg}</p> */}

    <Router>
      <Navbar/>  {/* Navbar always visible*/}
      <Routes>
         {/* Default Route --> Loads login reg first */}
         <Route path="/" element={<Register />} />
          <Route path="/login" element={<Login/>} />

          {/* Wrapping dashboard in protected route */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard/>
              </ProtectedRoute>
            }
          />
          {/* Add logout route */}
          <Route path="/logout" element={<Logout/>} />
      </Routes>
    </Router>
    </>
        
  );
}
export default App
