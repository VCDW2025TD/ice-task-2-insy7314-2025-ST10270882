//adding unit etstigng & linitng
module.exports = {
    testEnvironment: "node",
    testMatch: ["**/test/**/*.test.js"],
    verbose: true
};