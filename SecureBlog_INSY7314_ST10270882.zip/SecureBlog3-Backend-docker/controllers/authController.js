const jwt = require("jsonwebtoken");
const User = require("../models/User");

//Added -- Secure Login --> 4) Enforce Validation in the controller
const { validationResult } = require("express-validator");


//Create JWT with user ID in payload
const generateToken = (userId) =>
    jwt.sign({ id: userId}, process.env.JWT_SECRET, {expiresIn: "1h"});

//Register new user
// exports.register = async (req, res) => {
//     const {email, password} = req.body;
//     try{
//         const existing = await User.findOne({email});
//         if (existing) return res.status(400).json({message: "Email already exists"});
    
//         const user = await User.create({email, password});
//         const token = generateToken(user.id);
//         res.status(201).json({ token });
//     } catch (err){
//         res.status(500).json({error: `Server Error: ${err}`});
//     }
// };

exports.register = async (req,res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty())
        return res.status(400).json( { message: "Invalid input", errors: errors.array()});

    try{
        //  const { username, email, password } = req.body;
        // const {email, password} = req.body;
        //replaced for roles
        const {email, password, role} = req.body;

        // const exists = await User.findOne({ $or: [{ email }, { username }] });
         const existing = await User.findOne({email});
        if (existing) return res.status(400).json({message: "Email already exists"});

        //  const user = await User.create({email, password});
        const user = await User.create({email, password, role});
        //addedd
         const token = jwt.sign({id: user._id, role: user.role}, process.env.JWT_SECRET, { expiresIn : "1h"})
         return res.status(201).json({ id: user._id, email: user.email, role: user.role, token });
    } catch (e){
          console.log(e)
          return res.status(500).json({ message: `Server Error: ${e}` });
    }
}


// //Login for existinng user
// exports.login = async (req, res) => {
//     const {email, password} = req.body;
//     try{
//         const user = await User.findOne({ email});
//         if (!user || !(await user.comparePassword(password))) {
//             return res.status(400).json({message: "Invalid credentials"});
//         }

//         const token = generateToken(user._id);
//         res.json({token});
//     } catch (err){
//         res.status(500).json({error: `Server Error: ${err}`});

//     }
// };

exports.login = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty())
    return res.status(400).json({ message: "Invalid input", errors: errors.array() });

  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(401).json({ message: "Invalid credentials" });

    const ok = await user.comparePassword(password);
    if (!ok) return res.status(401).json({ message: "Invalid credentials" });

    const token = jwt.sign({ sub: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: "2h" });
    return res.json({ token, user: { id: user._id, role: user.role } });
  } catch (e) {
    console.log(e)
    // return res.status(500).json({ message: "Server error" });
     return res.status(500).json({ message: e.message });
  }
};


//added for admin create
// POST /api/auth/admin/create-user  (admin only)
// Admin can create users with any role (including editor/admin)
exports.adminCreateUser = async (req, res, next) => {
  try {
    const { email, password, role } = req.body;

    const user = await User.create({ email, password, role });
    // const token = signToken(user); // handy for logging in the created user (optional)

    // res.status(201).json({
    //   token,
    //   user: { id: user._id, email: user.email, role: user.role }

      
    res.status(201).json({
      user: { id: user._id, email: user.email, role: user.role }
    });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ message: "Email already registered" });
    }
    next(err);
  }
};




//temp added

exports.seedAdmin = async (req, res) => {
  try {
    const user = await User.create({
      email: "admin@gmail.com",
      password: "admin123", // this will get hashed if you have pre-save hook
      role: "admin"
    });
    res.json({ message: "Admin created", user });
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "Error creating admin" });
  }
};




